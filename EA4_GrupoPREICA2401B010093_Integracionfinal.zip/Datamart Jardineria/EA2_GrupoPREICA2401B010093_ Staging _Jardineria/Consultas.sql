--Tablas de origen

--TableDetalle_pedido
SELECT ID_detalle_pedido,cantidad, ID_producto
FROM detalle_pedido
ORDER BY 2 DESC
--TablePago
SELECT ID_pago, ID_cliente, total
FROM pago
ORDER BY total DESC
--TableCliente
SELECT ID_cliente, nombre_cliente,apellido_contacto, limite_credito
FROM cliente
ORDER BY ID_cliente ASC
--TableProducto
SELECT ID_producto, nombre,Categoria, cantidad_en_stock,CodigoProducto,precio_venta,precio_proveedor
FROM producto
ORDER BY ID_producto ASC
--TablePedido
SELECT DISTINCT fecha_pedido
FROM pedido


--Tablas de destino

--TableProducto
CREATE TABLE "Destino_TB_ProductoST" (
    "ID_producto" identity (1,1),
    "ID_producto_O" int,
    "nombre" nvarchar(70),
    "Categoria" int,
    "cantidad_en_stock" smallint,
    "CodigoProducto" nvarchar(15),
    "precio_venta" numeric(15,2),
    "precio_proveedor" numeric(15,2)
PRIMARY KEY( "ID_producto" )
)

--TableTiempo
CREATE TABLE "Destino_TB_TiempoST" (
    "ID_tiempo" int identity (1,1),
    "fecha" date
PRIMARY KEY( "ID_tiempo" )
)

--TableCliente
CREATE TABLE "Destino_TB_ClienteST" (
    "ID_cliente" int identity (1,1),
    "ID_cliente_O" int,
    "nombre_cliente" nvarchar(50),
    "apellido_contacto" nvarchar(30),
    "limite_credito" numeric(15,2)
PRIMARY KEY( "ID_cliente" )
)

--TableDetalle_Pedido
CREATE TABLE "Destino_TB_Detalle_PedidoST" (
    "ID_detalle_pedido" int identity (1,1),
    "ID_detalle_pedido_O" int,
    "cantidad" int,
    "ID_producto" int
PRIMARY KEY( "ID_detalle_pedido" )
)

--TablePago
CREATE TABLE "Destino_TB_PagoST" (
    "ID_pago" int identity (1,1),
    "ID_pago_O" int,
    "ID_cliente" int,
    "total" numeric(15,2)
PRIMARY KEY( "ID_pago" )
)

--Limpiar tablas
truncate table Destino_TB_ClienteST
truncate table Destino_TB_ProductoST
truncate table Destino_TB_TiempoST
truncate table Destino_TB_Detalle_PedidoST
truncate table Destino_TB_PagoST