CREATE TABLE "DimTiempoDM" (
    "ID_tiempo" int,
    "fecha" date,
    "Anio" int,
    "Mes" int,
    "Dia" int,
primary key ( "ID_tiempo" )
)


CREATE TABLE "DimProducto" (
    "ID_producto" int,
    "nombre" nvarchar(70),
    "Categoria" int,
    "cantidad_en_stock" smallint,
    "CodigoProducto" nvarchar(15),
    "precio_venta" numeric(15,2),
    "precio_proveedor" numeric(15,2)
primary key ( "ID_producto" )
)


CREATE TABLE "DimCliente" (
    "ID_cliente" int,
    "nombre_cliente" nvarchar(50),
    "apellido_contacto" nvarchar(30),
    "limite_credito" numeric(15,2)
primary key ( "ID_cliente" )
)

CREATE TABLE "FACVentasDM" (
    "ID_pedido" int,
    "ID_producto" int,
    "ID_tiempo" int,
    "ID_cliente" int,
    "cantidad" int,
    "total_venta" numeric(15,2)
primary key ( "ID_pedido" )
)