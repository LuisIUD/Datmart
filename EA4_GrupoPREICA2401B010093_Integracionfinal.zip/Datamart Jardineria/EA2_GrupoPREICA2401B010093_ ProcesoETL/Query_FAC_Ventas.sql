--Origen

SELECT 
	P.ID_pedido,
	P.ID_pedido_O,
    DP.ID_producto,
	dt.ID_tiempo,
    P.ID_cliente,
    DP.cantidad,
    PG.total_venta
FROM 
    Destino_TB_Detalle_PedidoST DP
INNER JOIN 
    Destino_TB_PedidoST P ON DP.ID_pedido = P.ID_pedido
INNER JOIN 
    Destino_TB_PagoST PG ON P.ID_cliente = PG.ID_cliente
INNER JOIN 
    DimTiempo DT ON P.fecha_pedido = dt.fecha;


--Destino

CREATE TABLE "DestinoFACVentasSt" (
    "ID_pedido" int,
    "ID_pedido_O" int,
    "ID_producto" int,
    "ID_tiempo" int,
    "ID_cliente" int,
    "cantidad" int,
    "total_venta" numeric(15,2)
)
